   ( exports.handler = async(event)  => {
    const nodemailer = require('nodemailer');
    const user = "totvsempresa123456"
    const pass = "74123felipe"



    var md5 = require('md5');
   async function wait(event){
       await event
   }
   wait(event);
    async function senha (hours, viewrs, passwords, email){
        console.log(1)
        var md5 = require('md5');
        const Sequelize = require('sequelize');
        const sequelize = new Sequelize('senhas', "admin", "admin123456", {
            host : "agora-vai-pfvr.cmmqkp6raeke.us-east-1.rds.amazonaws.com",
            dialect : 'mysql'
        })
        console.log(2)
        const Senhas = await sequelize.define('password',{
            id:{
                type: Sequelize.INTEGER,
                autoIncrement: true,
                allowNull: false,
                primaryKey: true
            },
            senha:{
                type: Sequelize.STRING,
                allowNull: false,
            },
            views:{
                type: Sequelize.STRING,
                allowNull: false,
            },
            horas:{
                type: Sequelize.STRING,
                allowNull: false,
            },
            link:{
                type: Sequelize.STRING,
                allowNull: false,
            },
        })
        console.log(3)
        const novaSenha = await Senhas.create({
            senha: passwords,
            views: viewrs,
            horas: hours,
            link: md5(passwords)
        })
        const teste = await sequelize.sync();
        console.log(teste)
        return teste
        }
        const senhaCliente = Math.random().toString(36).substring(0, 15);

        if ( JSON.stringify(event) !== undefined){
            await wait(senha(JSON.stringify(event.horas),JSON.stringify(event.views),senhaCliente));
        console.log(JSON.stringify(event.views));
        console.log(JSON.stringify(event.horas));
        let transporter = nodemailer.createTransport({
            host:"smtp.gmail.com",
            port: 587,
            auth:{user,pass}
        });
    
       await transporter.sendMail({
            from:user,
            to: JSON.stringify(event.email),
            subject: "Chave de acesso ",
            text:"Ola, sua chave de acesso para sua senha : "+md5(senhaCliente),
        });
        }
        const response = {
            statusCode: 200,
            body: JSON.stringify(md5(senhaCliente)),
        };
        return response;
    
})();
